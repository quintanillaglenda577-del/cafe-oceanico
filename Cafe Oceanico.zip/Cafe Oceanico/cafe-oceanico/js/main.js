/* ==========================================================
   EDITA TUS DATOS AQUÍ
   ========================================================== */
var C = {
  whatsapp: '50499761401',          // código de país + número, sin + ni espacios
  visible: '+504 9976-1401',        // así se ve escrito en la página
  msg: 'Hola Café Oceánico, me gustaría recibir información sobre sus cafés.',
  email: 'correo@ejemplo.com',      // CAMBIA por el correo real
  ig: 'https://www.instagram.com/cafeoceanicohn',   // CAMBIA por el real
  fb: 'https://www.facebook.com/cafeoceanicohn',    // CAMBIA por el real
  // Enlaces exactos de Google Maps de cada tienda (opcional).
  // Si lo dejas vacío, se busca por nombre y ciudad.
  maps: {
    'Mercadito La Despensa': '',
    'Mercadito Lidia #1 y #2': '',
    'Cafetería Amor y Café': '',
    'CIHCAFE': ''
  }
};

var Q = {
  'Mercadito La Despensa': 'Mercadito La Despensa, Santa Rosa de Copán, Honduras',
  'Mercadito Lidia #1 y #2': 'Mercadito Lidia, Santa Rosa de Copán, Honduras',
  'Cafetería Amor y Café': 'Cafetería Amor y Café, Santa Rosa de Copán, Honduras',
  'CIHCAFE': 'CIHCAFE, Cucuyagua, Copán, Honduras'
};

/* ==========================================================
   DATOS DE CONTACTO (WhatsApp, correo, redes, mapas)
   ========================================================== */
var $ = function (s) { return document.querySelectorAll(s); };

$('[data-wa]').forEach(function (a) {
  a.href = 'https://wa.me/' + C.whatsapp + '?text=' + encodeURIComponent(C.msg);
});
$('[data-mail]').forEach(function (a) { a.href = 'mailto:' + C.email; });
$('[data-ig]').forEach(function (a) { a.href = C.ig; });
$('[data-fb]').forEach(function (a) { a.href = C.fb; });
$('[data-watxt]').forEach(function (s) { s.textContent = C.visible; });
$('[data-mailtxt]').forEach(function (s) { s.textContent = C.email; });

document.getElementById('waTxt').textContent = C.visible;
document.getElementById('mailTxt').textContent = C.email;
document.getElementById('mail').href = 'mailto:' + C.email;
document.getElementById('ig').href = C.ig;
document.getElementById('fb').href = C.fb;

$('[data-map]').forEach(function (a) {
  var n = a.dataset.map;
  a.target = '_blank';
  a.rel = 'noopener';
  a.href = C.maps[n] || 'https://www.google.com/maps/search/?api=1&query=' + encodeURIComponent(Q[n]);
});

/* ==========================================================
   MENÚ: barra que se oscurece al bajar y menú en celular
   ========================================================== */
var hdr = document.getElementById('top');
var menu = document.getElementById('menu');

function onScroll() {
  hdr.classList.toggle('solid', scrollY > 40);
}
onScroll();
addEventListener('scroll', onScroll, { passive: true });

document.getElementById('burger').onclick = function () {
  menu.classList.toggle('open');
};
menu.querySelectorAll('a').forEach(function (a) {
  a.onclick = function () { menu.classList.remove('open'); };
});

/* ==========================================================
   SECCIONES: muestra solo la que se toca en el menú
   ========================================================== */
var views = document.querySelectorAll('.view');
var links = menu.querySelectorAll('a');

function go(id) {
  var el = document.getElementById(id);
  views.forEach(function (v) { v.classList.toggle('on', v.id === id); });
  links.forEach(function (a) { a.classList.toggle('on', a.getAttribute('href') === '#' + id); });
  if (!el || !el.classList.contains('view')) {
    scrollTo({ top: 0, behavior: 'smooth' });
    return;
  }
  scrollTo({ top: el.getBoundingClientRect().top + scrollY - 56, behavior: 'smooth' });
}

document.querySelectorAll('a[href^="#"]').forEach(function (a) {
  a.addEventListener('click', function (e) {
    e.preventDefault();
    var id = a.getAttribute('href').slice(1);
    history.replaceState(null, '', '#' + id);
    go(id);
  });
});

if (location.hash && location.hash !== '#inicio') go(location.hash.slice(1));